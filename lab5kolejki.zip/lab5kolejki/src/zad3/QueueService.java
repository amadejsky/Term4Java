package zad3;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.Queue;

public class QueueService {
    private Queue<LocalDateTime> freeVisits;
    private Queue<Patient> patients;

    public QueueService() {
        freeVisits = new LinkedList<>();
        patients= new LinkedList<>();
    }
    //Jeżeli jest dostępny termin oraz w kolejce czeka pacjent należy zapisać danego
    //pacjenta na wolny termin wyświetlając odpowiednią informację na konsoli.
    private void checkIfCanBeConsumed() {
        if (freeVisits.peek() != null && patients.peek() != null) {
            LocalDateTime visit = freeVisits.poll();
            Patient patient = patients.poll();
            System.out.println("Patient " + patient + " is scheduled on " + visit);
        }
    }
    //- Dodanie przez lekarza nowych dostępnych godzin (LocalDateTime) (przy dodawaniu
    //każdej godziny, jeśli jest oczekujący pacjent zapisz go na tę godzinę)
}
